$(document).ready(function (){

    $('.myslider').slick({

        infinite: true,
        focusOnSelect: false,
        pauseOnHover: false,
        pauseOnFocus: false,
        autoplay: true,
        fade: true,
        autoplaySpeed: 4000,
    });
});